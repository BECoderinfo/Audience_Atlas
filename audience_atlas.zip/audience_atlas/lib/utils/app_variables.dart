import 'import.dart';

class AppVariables {

  static final box = GetStorage();
  static final connect = GetConnect();

}