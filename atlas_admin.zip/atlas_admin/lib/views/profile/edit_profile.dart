import 'package:atlas_admin/controllers/profile/profile_controller.dart';
import 'package:atlas_admin/utils/import.dart';

class EditAdminProfilePage extends StatelessWidget {
  const EditAdminProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    final AdminProfileController controller = Get.find();

    final TextEditingController nameController =
        TextEditingController(text: controller.name.value);
    final TextEditingController emailController =
        TextEditingController(text: controller.email.value);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Profile'),
        actions: [
          Obx(
            () => (controller.isLoading.value)
                ? CircularProgressIndicator()
                : IconButton(
                    onPressed: () {
                      if (controller.formKey.currentState!.validate()) {
                        controller.updateProfile(
                          newName: nameController.text,
                          newEmail: emailController.text,
                        );
                      }
                    },
                    icon: const Icon(Icons.save),
                  ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              flex: 1,
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(color: AppColors.blackColor),
                  shape: BoxShape.circle,
                ),
                padding: EdgeInsets.all(6),
                child: Obx(
                  () => CircleAvatar(
                    radius: 50,
                    backgroundImage:
                        (controller.profileImage.value.startsWith('http'))
                            ? NetworkImage(
                                controller.profileImage.value,
                              )
                            : FileImage(
                                File(controller.profileImage.value),
                              ),
                    child: IconButton(
                      icon: Icon(
                        Icons.camera_alt,
                        color: Colors.white,
                      ),
                      onPressed: () {
                        controller.changeImage();
                      },
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              flex: 3,
              child: Form(
                key: controller.formKey,
                child: Column(
                  spacing: 10,
                  children: [
                    TextFormField(
                      controller: nameController,
                      decoration: InputDecoration(labelText: 'Name'),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter a name';
                        }
                        return null;
                      },
                    ),
                    TextFormField(
                      controller: emailController,
                      enabled: false,
                      decoration: InputDecoration(labelText: 'Email'),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter a email';
                        } else if (!GetUtils.isEmail(value)) {
                          return 'Please enter a valid email';
                        }
                        return null;
                      },
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
