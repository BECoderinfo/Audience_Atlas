import 'package:atlas_admin/controllers/profile/profile_controller.dart';
import 'package:atlas_admin/utils/import.dart';
import 'package:atlas_admin/views/profile/edit_profile.dart';

class AdminProfilePage extends StatelessWidget {
  const AdminProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    final AdminProfileController controller = Get.put(AdminProfileController());

    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Profile'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 20),
            Align(
              alignment: Alignment.center,
              child: Obx(
                () => CircleAvatar(
                  radius: 50,
                  backgroundImage: controller.profileImage.value.isNotEmpty
                      ? NetworkImage(controller.profileImage.value)
                      : const NetworkImage(
                              'https://img-cdn.pixlr.com/image-generator/history/65bb506dcb310754719cf81f/ede935de-1138-4f66-8ed7-44bd16efc709/medium.webp')
                          as ImageProvider,
                ),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              controller.name.value,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            Text(controller.email.value,
                style: const TextStyle(fontSize: 16, color: Colors.grey)),

            const SizedBox(height: 30),

            // Edit Profile Button
            Divider(),
            ListTile(
              leading: const Icon(Icons.edit),
              title: const Text('Edit Profile'),
              trailing: IconButton(
                onPressed: () {
                  Get.to(() => const EditAdminProfilePage());
                },
                icon: Icon(Icons.outbound_outlined),
              ),
              onTap: () => Get.to(() => const EditAdminProfilePage()),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Divider(),
            ),
            ListTile(
              leading: const Icon(Icons.key),
              title: const Text('Update Password'),
              trailing: IconButton(
                onPressed: () {
                  Get.toNamed(Routes.updatePassword);
                },
                icon: Icon(Icons.outbound_outlined),
              ),
              onTap: () {
                Get.toNamed(Routes.updatePassword);
              },
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Divider(),
            ),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('Logout'),
              trailing: IconButton(
                onPressed: () {},
                icon: Icon(Icons.outbound_outlined),
              ),
              onTap: () => controller.showLogoutDialog(),
            ),
            Divider(),
          ],
        ),
      ),
    );
  }
}
