import 'package:atlas_admin/controllers/publishers/publish_video_controller.dart';
import 'package:atlas_admin/utils/import.dart';
import 'package:video_player/video_player.dart';

class PublishVideo extends StatelessWidget {
  const PublishVideo({super.key});

  @override
  Widget build(BuildContext context) {
    final String? videoId = Get.arguments?['videoId'];

    return GetX<PublishVideoController>(
      init: PublishVideoController()..loadExistingVideo(videoId),
      builder: (controller) => Scaffold(
        appBar: AppBar(
          title: Text(
            videoId != null ? "Update Video" : "Publish Video",
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    _buildSectionTitle("Video Preview"),
                    Spacer(),
                    IconButton(
                      onPressed: controller.pickVideo,
                      icon: const Icon(Icons.video_library),
                    )
                  ],
                ),
                Obx(() {
                  String videoPath = controller.selectedVideoPath.value;
                  String videoUrl = controller.selectedVideoUrl.value;
                  return videoPath.isNotEmpty
                      ? VideoPreview(videoPath)
                      : videoUrl.isNotEmpty
                          ? VideoPreview(videoUrl)
                          : _buildPlaceholder("No video selected");
                }),
                Row(
                  children: [
                    _buildSectionTitle("Thumbnail Preview"),
                    Spacer(),
                    IconButton(
                      onPressed: controller.pickThumbnail,
                      icon: const Icon(Icons.image),
                    )
                  ],
                ),
                Obx(() {
                  String thumbPath = controller.thumbnailPath.value;
                  String thumbUrl = controller.thumbnailUrl.value;
                  return thumbPath.isNotEmpty
                      ? ThumbnailPreview(thumbPath)
                      : thumbUrl.isNotEmpty
                          ? ThumbnailPreview(thumbUrl)
                          : _buildPlaceholder("No thumbnail selected");
                }),
                const SizedBox(height: 20),
                TextField(
                  controller: controller.videoTitleController,
                  decoration: const InputDecoration(labelText: "Video Title"),
                ),
                const SizedBox(height: 30),
                ElevatedButton(
                  onPressed: () {
                    videoId != null
                        ? controller.updateVideo(videoId)
                        : controller.uploadVideo();
                  },
                  child: controller.isLoading.value
                      ? const CircularProgressIndicator()
                      : Text(videoId != null ? "Update Video" : "Upload Video"),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: Colors.blueAccent,
        ),
      ),
    );
  }
}

class VideoPreview extends StatefulWidget {
  final String videoPath;

  const VideoPreview(this.videoPath, {super.key});

  @override
  _VideoPreviewState createState() => _VideoPreviewState();
}

class _VideoPreviewState extends State<VideoPreview> {
  VideoPlayerController? _videoController;
  bool isPlaying = false;

  @override
  void initState() {
    super.initState();
    if (widget.videoPath.isNotEmpty) {
      _initializeVideo();
    }
  }

  void _initializeVideo() {
    if (widget.videoPath.startsWith('http')) {
      _videoController =
          VideoPlayerController.networkUrl(Uri.parse(widget.videoPath))
            ..initialize().then((_) {
              if (mounted) {
                setState(() {});
              }
            });
    } else {
      _videoController = VideoPlayerController.file(File(widget.videoPath))
        ..initialize().then((_) {
          if (mounted) {
            setState(() {});
          }
        });
    }
  }

  @override
  void didUpdateWidget(covariant VideoPreview oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.videoPath != widget.videoPath &&
        widget.videoPath.isNotEmpty) {
      _videoController?.dispose();
      _initializeVideo();
    }
  }

  @override
  Widget build(BuildContext context) {
    return widget.videoPath.isNotEmpty &&
            _videoController != null &&
            _videoController!.value.isInitialized
        ? Stack(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: AspectRatio(
                  aspectRatio: _videoController!.value.aspectRatio,
                  child: VideoPlayer(_videoController!),
                ),
              ),
              Positioned(
                child: IconButton(
                  onPressed: () {
                    setState(() {
                      isPlaying = !isPlaying;
                      isPlaying
                          ? _videoController!.play()
                          : _videoController!.pause();
                    });
                  },
                  icon: Icon(
                    isPlaying ? Icons.pause : Icons.play_arrow,
                    color: Colors.white,
                    size: 32,
                  ),
                ),
              ),
            ],
          )
        : _buildPlaceholder("No video selected");
  }

  @override
  void dispose() {
    _videoController?.dispose();
    super.dispose();
  }
}

class ThumbnailPreview extends StatelessWidget {
  final String thumbnailPath;

  const ThumbnailPreview(this.thumbnailPath, {super.key});

  @override
  Widget build(BuildContext context) {
    return thumbnailPath.isNotEmpty
        ? ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: thumbnailPath.startsWith('http')
                ? Image.network(thumbnailPath, height: 200, fit: BoxFit.cover)
                : Image.file(File(thumbnailPath),
                    height: 200, fit: BoxFit.cover),
          )
        : _buildPlaceholder("No thumbnail selected");
  }
}

Widget _buildPlaceholder(String text) {
  return Container(
    height: 200,
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(10),
      color: Colors.grey[300],
    ),
    child: Center(
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.bold,
          color: Colors.grey,
        ),
      ),
    ),
  );
}
