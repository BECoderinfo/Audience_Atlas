import 'package:atlas_admin/utils/import.dart';

class UpdateVideo extends StatelessWidget {
  const UpdateVideo({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
