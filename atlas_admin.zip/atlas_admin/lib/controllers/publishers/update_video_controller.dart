import 'package:atlas_admin/utils/import.dart';

class UpdateVideoController extends GetxController {}
