import 'package:atlas_admin/utils/import.dart';

class CreatePublisherController extends GetxController {
  BuildContext ctx = Get.context!;

  GlobalKey<FormState> formKey = GlobalKey<FormState>();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  RxBool isPasswordVisible = false.obs;

  RxBool isLoading = false.obs;

  void createPublisher() async {
    try {
      isLoading = true.obs;

      var res = await ApiService.postApi(Apis.createPublisher, ctx, body: {
        'email': emailController.text,
        'password': passwordController.text
      });

      if (res != null) {
        Get.snackbar("Success", "Publisher created successfully!");
        Get.offNamed(Routes.publishers);
      }
      update();
    } catch (e) {
      Get.snackbar("Error", "Failed to create publisher: $e");
    } finally {
      isLoading = false.obs;
      update();
    }
  }
}
