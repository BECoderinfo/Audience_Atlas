import 'package:atlas_admin/utils/import.dart';
import 'package:file_picker/file_picker.dart';

class AdminProfileController extends GetxController {
  BuildContext ctx = Get.context!;
  var name = 'Admin Name'.obs;
  var email = 'admin@example.com'.obs;
  var profileImage = ''.obs; // URL of profile image

  var uploadImage = ''.obs;

  var formKey = GlobalKey<FormState>();

  RxBool isLoading = false.obs;

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    name.value = AppVariables.box.read(StorageKeys.aName) ?? "Admin";
    email.value =
        AppVariables.box.read(StorageKeys.aEmail) ?? "admin@example.com";
    if (AppVariables.box.read(StorageKeys.aImage) != null) {
      profileImage.value =
          "${Apis.serverAddress}/${AppVariables.box.read(StorageKeys.aImage)}";
    } else {
      profileImage.value = AppVariables.box.read(StorageKeys.aImage) ??
          'https://img-cdn.pixlr.com/image-generator/history/65bb506dcb310754719cf81f/ede935de-1138-4f66-8ed7-44bd16efc709/medium.webp';
    }
  }

  Future<void> changeImage() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.image,
    );

    if (result != null) {
      File file = File(result.files.single.path!);
      profileImage.value = file.path; // Update the observable image
      uploadImage.value = file.path;
    } else {
      Get.snackbar("Image Selection", "you did not select image",
          snackPosition: SnackPosition.values[0]);
    }
  }

  void updateProfile({
    required String newName,
    required String newEmail,
  }) async {
    try {
      isLoading.value = true;

      if (uploadImage.value == "") {
        var res = await ApiService.putApi(
          Apis.updateAdminProfile(
              userId: AppVariables.box.read(StorageKeys.aId)),
          ctx,
          body: {
            'name': newName,
            'email': newEmail,
          },
        );

        if (res != null) {
          AppVariables.box.write(StorageKeys.aName, newName);
          AppVariables.box.write(StorageKeys.aEmail, newEmail);
          Get.back();
        }
      } else {
        var res = await ApiService.multipartApi(
          Apis.updateAdminProfile(
              userId: AppVariables.box.read(StorageKeys.aId)),
          ctx,
          method: 'PUT',
          imageParamName: 'image',
          imagePath: [uploadImage.value],
          body: {
            'name': newName,
            'email': newEmail,
          },
        );

        if (res != null) {
          AppVariables.box.write(StorageKeys.aName, newName);
          AppVariables.box.write(StorageKeys.aEmail, newEmail);
          AppVariables.box.write(StorageKeys.aImage, res['admin']['image']);
          profileImage.value = '${Apis.serverAddress}/${res['admin']['image']}';
          Get.back();
        }
      }
    } catch (e) {
      log(e.toString());
      Get.snackbar("Error", "Failed to update profile");
    } finally {
      isLoading.value = false;
    }
  }

  void showLogoutDialog() {
    Get.defaultDialog(
      title: "Logout",
      titleStyle: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
      middleText: "Are you sure you want to log out?",
      middleTextStyle: const TextStyle(fontSize: 16),
      backgroundColor: Colors.white,
      radius: 8,
      barrierDismissible: false,
      // Prevents dismissing by tapping outside
      actions: [
        TextButton(
          onPressed: () => Get.back(), // Close dialog
          child: const Text("Cancel", style: TextStyle(color: Colors.grey)),
        ),
        TextButton(
          onPressed: () {
            Get.back(); // Close dialog first
            logoutUser(); // Call logout function
          },
          child: const Text("Logout"),
        ),
      ],
    );
  }

  /// Your logout function
  void logoutUser() {
    AppVariables.box.remove(StorageKeys.isLoggedIn);
    AppVariables.box.remove(StorageKeys.aId);
    AppVariables.box.remove(StorageKeys.role);
    Get.offAllNamed(
      Routes.login,
    );
  }
}
