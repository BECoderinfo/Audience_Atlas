import 'package:atlas_admin/utils/import.dart';

class UpdatePasswordController extends GetxController {
  String role = AppVariables.box.read(StorageKeys.role) ?? "Admin";

  TextEditingController oldPasswordController = TextEditingController();
  TextEditingController newPasswordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();

  RxBool isOldPasswordVisible = false.obs;
  RxBool isNewPasswordVisible = false.obs;
  RxBool isConfirmPasswordVisible = false.obs;
  RxBool isLoading = false.obs;

  void toggleOldPasswordVisibility() {
    isOldPasswordVisible.value = !isOldPasswordVisible.value;
  }

  void toggleNewPasswordVisibility() {
    isNewPasswordVisible.value = !isNewPasswordVisible.value;
  }

  void toggleConfirmPasswordVisibility() {
    isConfirmPasswordVisible.value = !isConfirmPasswordVisible.value;
  }

  Future<void> updatePassword() async {
    if (oldPasswordController.text.isEmpty ||
        newPasswordController.text.isEmpty ||
        confirmPasswordController.text.isEmpty) {
      Get.snackbar("Error", "All fields are required");
      return;
    }

    if (newPasswordController.text != confirmPasswordController.text) {
      Get.snackbar("Error", "New passwords do not match");
      return;
    }

    isLoading.value = true;

    try {
      var res = await ApiService.putApi(
          (role == 'Admin') ? Apis.updatePassword : Apis.updatePubPassword,
          Get.context!,
          body: {
            "email": AppVariables.box.read(StorageKeys.aEmail),
            "currentPassword": oldPasswordController.text,
            "newPassword": newPasswordController.text,
            "confirmPassword": newPasswordController.text,
          });

      if (res == null) {
        Get.snackbar("Error", "Failed to update password");
        return;
      }

      Get.snackbar("Success", "Password updated successfully");
      oldPasswordController.clear();
      newPasswordController.clear();
      confirmPasswordController.clear();
      Get.back();
    } catch (e) {
      Get.snackbar("Error", "Something went wrong");
    } finally {
      isLoading.value = false;
    }
  }
}
