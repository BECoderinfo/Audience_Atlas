package com.example.atlas_admin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
